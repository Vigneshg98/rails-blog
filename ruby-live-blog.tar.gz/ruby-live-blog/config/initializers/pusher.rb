require 'pusher'

Pusher.app_id = '846740'
Pusher.key = '77ce7ed0a989fd481c71'
Pusher.secret = '22462685fce3eb6a2ad8'
Pusher.cluster = 'ap2'
Pusher.logger = Rails.logger
Pusher.encrypted = true